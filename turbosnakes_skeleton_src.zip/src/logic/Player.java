package logic;

import map.Map;
import map.Switch_;
import skeleton.Logger_;

/**
 * Created by turbosnakes on 2017. 03. 13..
 */
public class Player {

    public int currentLevel;
    public String player_name; //name-et valamiért aláhúzta lilával és az sose jó xd

    /**
     * Ez a függvény kezeli a felhasználói bemenetet a játék során.
     */
    public void readCommand() {
        if (System_.currentUC == 10) {
            //A jelenlegi pálya és egy switch inicializálása.
            Map map = new Map();
            Switch_ switch_ = new Switch_();

            Logger_.logEvent(Logger_.logEventType.CALL, "Player", "readCommand", "Map", "setSwitch", "switch");
            //A váltó beállítása aktuálisként az adott pályán.
            map.setSwitch_(switch_);

            Logger_.logEvent(Logger_.logEventType.RETURN, "Player", "readCommand");

        }
    }
}
