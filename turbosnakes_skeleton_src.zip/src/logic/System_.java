package logic;

import map.Map;
import movingelement.Train;
import skeleton.Logger_;
import sun.reflect.generics.reflectiveObjects.NotImplementedException;

import java.util.ArrayList;

/**
 * Created by turbosnakes on 2017. 03. 13..
 */
public class System_ {
    public static int currentUC = 0; //Jelenleg futó UC száma.
    public static boolean ANSI_CONSOLE_ENABLED = false; //Képes-e a rendszer ANSI escape karakterek megjelenítésére.

    private ArrayList<Train> _trains;
    private Map _map;
    private Player _player;

    /**
     * Ez a függvény kezeli a játék elindításást.
     */
    public void start() {
        if (currentUC == 7) {
            Logger_.logEvent(Logger_.logEventType.CALL, "System_", "start", "Map", "create", "");
            Map map = new Map();
        }
    }

    /**
     * Ez a függvény kezeli a játék bezárását.
     */
    public void close() {
        throw new NotImplementedException();
    }

    /**
     * Ez a függvény kezeli az idő haladását, azaz a játékban való képtetést.
     */
    public void nextStep_() {
        throw new NotImplementedException();
    }

    /**
     * Ez a függvény kezeli azt az esetet, amikor a játékos veszít.
     */
    public void gameOver() {
        if (logic.System_.currentUC == 4 || System_.currentUC == 9 || System_.currentUC == 81) {
            Logger_.logEvent(Logger_.logEventType.RETURN, "System_", "gameOver");
        }
    }

}
