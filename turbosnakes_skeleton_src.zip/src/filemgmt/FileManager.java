package filemgmt;

import logic.System_;
import map.Map;
import skeleton.Logger_;
import sun.reflect.generics.reflectiveObjects.NotImplementedException;

import java.io.File;

/**
 * Created by turbosnakes on 2017. 03. 13..
 */
public class FileManager {
    private String _workingDirectory;

    public void save(Map map) {
        throw new NotImplementedException();
    }

    /**
     * Visszatér egy fájlal, amelyben a kimentett pálya található
     */
    public static File load() {
        if (System_.currentUC == 7) {
            Logger_.logEvent(Logger_.logEventType.RETURN, "FilaManager", "load");
        }
        return null;
    }

}
