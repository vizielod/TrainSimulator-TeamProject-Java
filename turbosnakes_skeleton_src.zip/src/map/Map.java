package map;

import filemgmt.FileManager;
import logic.System_;
import skeleton.Logger_;
import sun.reflect.generics.reflectiveObjects.NotImplementedException;

import java.util.ArrayList;

/**
 * Created by turbosnakes on 2017. 03. 13..
 */
public class Map {

    public ArrayList<MapElement> entrancePoints;
    private Tunnel _enabledTunnel;
    private FileManager _fm;

    /**
     * Map osztály konstruktora. A Játék elindításakor inicializálja a Map-ot, betölti a pályát egy fájlból, majd sorba létrehozza a pályaelemeket: Rail, Switch, TunnelEntrance, Station.
     * Mivel ez csak egy példaprogram, hogy szemléltesse az osztály működését, ezért elemenként csak egy példányt hozunk étre, de valójában sokkal több elemből fog állni a pálya
     */
    public Map() {
        if (System_.currentUC == 7) {
            Logger_.logEvent(Logger_.logEventType.CALL, "Map", "create", "Map", "loadFromFile", "");
            this.loadFromFile();
            Logger_.logEvent(Logger_.logEventType.RETURN, "Map", "create");

            Logger_.logEvent(Logger_.logEventType.CALL, "Map", "Map", "FileManager", "load", "");
            _fm.load();

            Logger_.logEvent(Logger_.logEventType.CALL, "Map", "create", "Rail", "create", "");
            Rail rail = new Rail();

            Logger_.logEvent(Logger_.logEventType.CALL, "Map", "create", "Station", "craete", "");
            Station station = new Station();

            Logger_.logEvent(Logger_.logEventType.CALL, "Map", "create", "Switch_", "create", "");
            Switch_ switch1 = new Switch_();

            Logger_.logEvent(Logger_.logEventType.CALL, "Map", "create", "TunnelEntrance", "create", "");
            TunnelEntrance te = new TunnelEntrance();

        }
    }

    public void inituc3() {
        if (logic.System_.currentUC == 3) {
            _enabledTunnel = new Tunnel();
        }
    }

    /**
     * Pálya betöltése egy fájlból.
     */
    public void loadFromFile() {
        if (System_.currentUC == 7) {
            Logger_.logEvent(Logger_.logEventType.RETURN, "Map", "loadFromFile");
        }
    }

    /**
     * Sorosítást végző függvény.
     */
    public void serialize() {
        throw new NotImplementedException();
    }

    public void enableTunnel(Tunnel tunnel) {
        if (System_.currentUC == 3) {
            //A ManageTunnel use case inicializáló függvényének meghívása.
            inituc3();
            Logger_.logEvent(Logger_.logEventType.CALL, "Map", "enableTunnel", "Tunnel", "disable", "");
            //Az új alagút létrehozása előtt a már létrehozott alagutat meg kell szüntetni
            _enabledTunnel.disable();
            Logger_.logEvent(Logger_.logEventType.CALL, "Map", "enableTunnel", "Tunnel", "enable", "");
            //Az új alagút megépítése
            tunnel.enable();
            Logger_.logEvent(Logger_.logEventType.RETURN, "Map", "enableTunnel");
        }
    }

    /**
     * A paraméterként átvett váltó állását megváltoztatja, eggyel lépteti.
     *
     * @param param_switch Megváltoztatni kívánt váltó.
     */
    public void setSwitch_(Switch_ param_switch) {
        if (System_.currentUC == 10) {
            Logger_.logEvent(Logger_.logEventType.CALL, "Map", "setSwitch_", "Switch", "switch", "");
            //A paraméterként kapott váltó állássát megváltoztatjuk.
            param_switch.switch_();

            Logger_.logEvent(Logger_.logEventType.RETURN, "Map", "setSwitch_");
        }
    }

}
