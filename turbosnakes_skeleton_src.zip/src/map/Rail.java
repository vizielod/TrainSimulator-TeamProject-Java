package map;

import logic.System_;
import movingelement.MovingElement;
import skeleton.Logger_;

import java.util.ArrayList;
import java.util.Scanner;


/**
 * Created by turbosnakes on 2017. 03. 13..
 */
public class Rail extends MapElement {

    public Rail() {
        if (System_.currentUC == 7) {
            Logger_.logEvent(Logger_.logEventType.RETURN, "Rail", "create");
        }
    }

    @Override
    public void setOccupied_(MovingElement currentElement) {
        if (logic.System_.currentUC == 4) {
            Logger_.logEvent(Logger_.logEventType.CALL, "Rail", "setOccupied_", "Train", "explode", "");
            currentElement.explode();
        }
        if (logic.System_.currentUC == 6) {
            Logger_.logEvent(Logger_.logEventType.RETURN, "Rail", "setOccupied_");
        }
        if (logic.System_.currentUC == 9) {
            Logger_.logEvent(Logger_.logEventType.CALL, "Rail", "setOccupied", "Rail", "getOccupied", "");
            //A robbanás vizsgálatához a tesztelőtől kérdezzük meg, hogy a következő pályaelemen áll-e már valaki.
            System.out.println("\nÁll már valaki az állomás utáni sínen? (0: Nem / 1: Igen)");
            Scanner sc = new Scanner(System.in);
            int input = sc.nextInt();
            if (input == 1) {
                Logger_.logEvent(Logger_.logEventType.CALL, "MapElement", "setOccupied", "Train", "explode", "");
                //Ha áll már valaki a következő pályaelemen, akkor a vonat felrobban.
                currentElement.explode();
            } else if (input != 0) throw new IllegalArgumentException();
            this.getOccupied_();

            Logger_.logEvent(Logger_.logEventType.RETURN, "Rail", "setOccupied_");
        }
        if(logic.System_.currentUC == 1){
            //Jelezzük a felhasználónak, hogy sikeresen megtörtént az "R2" setOccupied hívása.
            Logger_.logEvent(Logger_.logEventType.RETURN, "R2", "setOccupied_");
        }
        if (logic.System_.currentUC == 5) {
            Logger_.logEvent(Logger_.logEventType.RETURN, "Rail", "setOccupied_");
        }
        if(logic.System_.currentUC == 11){
            //Jelezzük a felhasználónak, hogy sikeresen megtörtént az "R3" setOccupied hívása.
            Logger_.logEvent(Logger_.logEventType.RETURN, "R3", "setOccupied_");
        }
        if(logic.System_.currentUC == 21) {
            //Jelezzük a felhasználónak, hogy sikeresen megtörtént az "A" setOccupied hívása.
            Logger_.logEvent(Logger_.logEventType.RETURN, "A", "setOccupied_");
        }
        if(logic.System_.currentUC == 22) {
            //Jelezzük a felhasználónak, hogy sikeresen megtörtént a "B" setOccupied hívása.
            Logger_.logEvent(Logger_.logEventType.RETURN, "B", "setOccupied_");
        }
    }

    /**
     * Különböző, az UC-k inicializálását végző függvények
     */
    public void inituc4() {
        if (logic.System_.currentUC == 4) {
            _neighbors = new ArrayList<>();
            _neighbors.add(new Rail());
        }
    }

    public void inituc1() {
        //Az MEonRail use case inicializáló függvénye, beállít egy szomszédot az adott sínnek.
        if (logic.System_.currentUC == 1 || logic.System_.currentUC == 11) {
            _neighbors = new ArrayList<>();
            _neighbors.add(new Rail());
        }
    }
    public void inituc2() {
        //Az MEonSwitch use case inicializáló függvénye, beállít egy Switchet szomszédnak az adott sínnek.
        if (logic.System_.currentUC == 2) {
            _neighbors = new ArrayList<>();
            _neighbors.add(new Switch_());
        }
    }

    public void inituc5() {
        if (logic.System_.currentUC == 5) {
            _neighbors = new ArrayList<>();
            _neighbors.add(new Rail());
        }
    }

    public void inituc8() {
        if (logic.System_.currentUC == 8) {
            _neighbors = new ArrayList<>();
            _neighbors.add(new Rail());
        }
    }

    @Override
    public MapElement getNext_(MapElement previousElement) {
        if (logic.System_.currentUC == 4) {
            inituc4();
            Logger_.logEvent(Logger_.logEventType.RETURN, "Rail", "getNext_");
        }
        if (logic.System_.currentUC == 1) {
            //Meghívjuk az inicializáló függvényt és jelezzük a felhasználónak, hogy visszatér az R1 sín függvénye.
            inituc1();
            Logger_.logEvent(Logger_.logEventType.RETURN, "R1", "getNext_");
        }
        if (logic.System_.currentUC == 11) {
            //A use case második fázisa, jelezzük, ugyanúgy inicializálunk, majd már a következő sín (R2) getNext-je tér vissza.
            inituc1();
            Logger_.logEvent(Logger_.logEventType.RETURN, "R2", "getNext_");
        }
        if (logic.System_.currentUC == 2){
            inituc2();
            Logger_.logEvent(Logger_.logEventType.RETURN, "R1", "getNext_");
        }
        if (logic.System_.currentUC == 5) {
            //A MEinTunnel use case inicializáló függvényének meghívása.
            inituc5();
            Logger_.logEvent(Logger_.logEventType.RETURN, "Rail", "getNext_");
            //visszatérünk a szomszédjával ami egy MapElement
        }
        if (logic.System_.currentUC == 8) {
            inituc8();
            Logger_.logEvent(Logger_.logEventType.RETURN, "R1", "getNext_");
        }
        return _neighbors.get(0);
    }

    @Override
    public MovingElement getOccupied_() {
        if (System_.currentUC == 3) {
            Logger_.logEvent(Logger_.logEventType.RETURN, "Rail", "getOccupied_");
            //visszatérünk a sínen lévő MovingElementtel
            return _occupiedBy;
        }

        if (System_.currentUC == 9) {
            Logger_.logEvent(Logger_.logEventType.RETURN, "Rail", "getOccupied");
            return _occupiedBy;
        }
        return null;
    }
}
