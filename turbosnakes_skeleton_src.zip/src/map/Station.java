package map;

import logic.System_;
import movingelement.MovingElement;
import movingelement.Train;
import skeleton.Logger_;
import sun.reflect.generics.reflectiveObjects.NotImplementedException;

import java.awt.*;
import java.util.ArrayList;

/**
 * Created by turbosnakes on 2017. 03. 13..
 */
public class Station extends MapElement {

    private Color _color;

    public Station() {
        if (System_.currentUC == 7) {
            Logger_.logEvent(Logger_.logEventType.RETURN, "Station", "create");
        }
    }

    public Color getColor() {
        if (logic.System_.currentUC == 9) {
            //Mivel a feladatnak nem volt része még a színek vizsgálata, a függvény null értékkel tér vissza.
            Logger_.logEvent(Logger_.logEventType.RETURN, "Station", "getColor");
        }
        return null;
    }

    @Override
    public void setOccupied_(MovingElement movingElement) {
        if (logic.System_.currentUC == 6) {
            Logger_.logEvent(Logger_.logEventType.RETURN, "Station", "setOccupied_");
        }
    }

    @Override
    public MovingElement getOccupied_() {
        throw new NotImplementedException();
    }

    @Override
    public MapElement getNext_(MapElement previousElement) {
        if (System_.currentUC == 9) {
            //A use case-nek megfelelő állás inicializálása.
            this._neighbors = new ArrayList<MapElement>();
            Rail rail = new Rail();
            Train train = new Train();
            this._neighbors.add(rail);

            //Amikor a vonat rálép egy MapElement-re, akkor erről az adott pályaelem tudomást szerez.
            this.setOccupied_(train);

            Logger_.logEvent(Logger_.logEventType.CALL, "Station", "getNext", "Train", "atStation", "");
            //Úgynevezett callback függvény. Ha az állomásra egy vonat ért, akkor megkezdődik az utasok leszállítása.
            train.atStation();

            Logger_.logEvent(Logger_.logEventType.RETURN, "Station", "getNext");
            //Visszatér a következő pályaelemmel. Nem végleges logika, kizárólag a teszteset miatt van így megvalósítva.
            return _neighbors.get(0);
        }
        return null;
    }

}
