package map;

import logic.System_;
import skeleton.Logger_;

import java.util.ArrayList;

/**
 * Created by turbosnakes on 2017. 03. 13..
 */
public class Tunnel {

    private ArrayList<TunnelEntrance> _exitPoints;
    private ArrayList<Rail> _tunnelRails;
    private Boolean _enabled;

    private void inituc3() {
        if (System_.currentUC == 3) {
            _tunnelRails = new ArrayList<>();
            _exitPoints = new ArrayList<>();
            _tunnelRails.add(new Rail());
            _exitPoints.add(new TunnelEntrance());
            _exitPoints.add(new TunnelEntrance());
        }
    }

    public void disable() {
        if (System_.currentUC == 3) {
            //A getOff use case inicializáló függvényének meghívása. Létrejön kettő alagút bejárat és egy sín, ami az alagútban van.
            inituc3();
            Logger_.logEvent(Logger_.logEventType.CALL, "Tunnel", "disable", "Rail", "getOccupied_", "");
            //Lekérdezzük, hogy az alagútban lévő sínen van-e MovingElement, ez azért szükséges, mert ottlévő vonatra vagy vagonra
            // nem zárható rá az alagút
            _tunnelRails.get(0).getOccupied_();
            Logger_.logEvent(Logger_.logEventType.CALL, "Tunnel", "disable", "TunnelEntrance", "getOccupied_", "");
            //Lekérdezzük, hogy az alagút egyik bejáratán van-e MovingElement, ez azért szükséges, mert ottlévő vonatra vagy vagonra
            // nem zárható rá az alagút
            _exitPoints.get(0).getOccupied_();
            Logger_.logEvent(Logger_.logEventType.CALL, "Tunnel", "disable", "TunnelEntrance", "getOccupied_", "");
            //Lekérdezzük, hogy az alagút másik bejáratán van-e MovingElement, ez azért szükséges, mert ottlévő vonatra vagy vagonra
            // nem zárható rá az alagút
            _exitPoints.get(1).getOccupied_();
            //Az alagút megszüntetése az ezt reprezentáló attribútum hamisra állításával.
            _enabled = false;
            Logger_.logEvent(Logger_.logEventType.RETURN, "Tunnel", "disable");
        }
    }

    public void enable() {
        //A getOff use case inicializáló függvényének meghívása. Létrejön kettő alagút bejárat és egy sín, ami az alagútban van.
        inituc3();
        Logger_.logEvent(Logger_.logEventType.RETURN, "Tunnel", "enable");
        //Az alagút létrehozása az ezt reprezentáló attribútum hamisra állításával.
        _enabled = true;
    }

}
