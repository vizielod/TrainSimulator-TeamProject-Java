package map;

import logic.System_;
import movingelement.MovingElement;
import skeleton.Logger_;
import sun.reflect.generics.reflectiveObjects.NotImplementedException;

import java.util.ArrayList;
import java.util.Scanner;

/**
 * Created by turbosnakes on 2017. 03. 13..
 */
public class Switch_ extends MapElement {

    public Switch_() {
        if (System_.currentUC == 7) {
            Logger_.logEvent(Logger_.logEventType.RETURN, "Switch_", "create");
        }
    }

    public void switch_() {
        if (System_.currentUC == 10) {
            //A váltás jelenleg cselekmény nélkül történik.
            Logger_.logEvent(Logger_.logEventType.RETURN, "Switch", "switch");
        }
    }

    @Override
    public void setOccupied_(MovingElement currentElement){
        if(logic.System_.currentUC == 2)
            //Jelezzük a felhasználónak, ha valamelyik MovingElement a switchre lép.
            Logger_.logEvent(Logger_.logEventType.RETURN, "Switch", "setOccupied_");
        if (logic.System_.currentUC == 8)
            Logger_.logEvent(Logger_.logEventType.RETURN, "Switch", "setOccupied_");
    }

    @Override
    public MovingElement getOccupied_() {
        throw new NotImplementedException();
    }

    public void inituc2(){
        //A MEonSwitch use case inicializálófüggvénye, ami a Switchnek beállít két sínt szomszédnak, amik majd a lehetséges kimeneteket adják.
        if(logic.System_.currentUC == 20){
            _neighbors = new ArrayList<MapElement>();
            _neighbors.add(new Rail());
            _neighbors.add(new Rail());
        }
    }

    @Override
    public MapElement getNext_(MapElement previousElement){
        if(logic.System_.currentUC == 20){
            //Meghívjuk az inicializáló függvényét a use casenek.
            inituc2();
            int input;
            //Bekérjük a felhasználótól, hogy melyik sínre szeretné, hogy a vonat továbbhaladjon.
            System.out.println("A vonat éppen egy váltón áll. Az A vagy B sínre szeretné, hogy továbbhaladjon? Ha rossz számot ad meg, a függvény visszatér és a Use Case befejeződik. (0 = A/ 1 = B)");
            Scanner sc = new Scanner(System.in);
            //Amíg nem számot ad meg a felhasználó, addig kérjük tőle a bemenetet.
            while (!sc.hasNextInt()) {
                System.out.println("Rossz bemenetet adott meg.");
                sc.next();
            }
            input = sc.nextInt();
            Logger_.logEvent(Logger_.logEventType.RETURN, "Switch", "getNext_");
            //Ha 0-t válaszottt azaz az "A" sínt akkor azzal térünk vissza következő elemként.
            if (input == 0){
                //Itt beállítjuk, hogy melyik irányban haladjon tovább a use case működése.
                logic.System_.currentUC = 21;
                return _neighbors.get(0);
            }
            //Ha a 1-t választott, azaz a "B" sínt akkor azzal térünk vissza következő elemként.
            if (input == 1){
                //Itt beállítjuk, hogy melyik irányban haladjon tovább a use case működése.
                logic.System_.currentUC = 22;
                return _neighbors.get(1);
            }
        }
        if (logic.System_.currentUC == 81) {
            Logger_.logEvent(Logger_.logEventType.RETURN, "Switch", "getNext_");
            return null;
        }
        return _neighbors.get(0);
    }

}
