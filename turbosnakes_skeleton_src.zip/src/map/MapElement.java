package map;

import movingelement.MovingElement;

import java.awt.*;
import java.util.ArrayList;

/**
 * Created by turbosnakes on 2017. 03. 13..
 */
public abstract class MapElement {
    protected Point _pos;
    protected MovingElement _occupiedBy;
    protected ArrayList<MapElement> _neighbors;

    /**
     * Absztrakt függvény a következő elem visszaadására
     *
     * @param previousElement Előző elem, ennek függvényében kapja a következőt. Tkp. az egyik szomédja annak, amin most áll.
     * @return A következő elem
     */
    public abstract MapElement getNext_(MapElement previousElement);

    /**
     * Absztrakt függvény, mellyel lekérdezhetjük, hogy mi által van éppen elfoglalva.
     *
     * @return Az elem, ami rajta áll.
     */
    public abstract MovingElement getOccupied_();

    /**
     * Asztrakt függvény, melyet akkor hívunk ha rálépünk az elemre.
     * @param currentElement A jelenlegi elem, ami rálépett.
     */
    public abstract void setOccupied_(MovingElement currentElement);
}
