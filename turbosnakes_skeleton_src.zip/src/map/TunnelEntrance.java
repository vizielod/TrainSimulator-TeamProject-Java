package map;

import logic.System_;
import movingelement.MovingElement;
import skeleton.Logger_;

import java.util.ArrayList;

/**
 * Created by turbosnakes on 2017. 03. 13..
 */
public class TunnelEntrance extends MapElement {

    public TunnelEntrance() {
        if (System_.currentUC == 7) {
            Logger_.logEvent(Logger_.logEventType.RETURN, "TunnelEntrance", "create");
        }
    }

    public void inituc51() {
        if (logic.System_.currentUC == 51) {
            _neighbors = new ArrayList<>();
            _neighbors.add(new TunnelEntrance());
        }
    }

    @Override
    public MapElement getNext_(MapElement previousElement) {
        if (logic.System_.currentUC == 51) {
            //A MEinTunnel use case inicializáló függvényének meghívása.
            inituc51();
            Logger_.logEvent(Logger_.logEventType.RETURN, "TunnelEntrance", "getNext_");
        }
        //visszatérünk a szomszédjával ami egy MapElement
        return _neighbors.get(0);
    }

    @Override
    public MovingElement getOccupied_() {
        if (System_.currentUC == 3) {
            Logger_.logEvent(Logger_.logEventType.RETURN, "TunnelEntrance", "getOccupied_");
        }
        // visszatérés a MovingElementtel, ami az adott MapElementen található
        return _occupiedBy;
    }

    @Override
    public void setOccupied_(MovingElement currentElement) {
        if (logic.System_.currentUC == 51) {
            Logger_.logEvent(Logger_.logEventType.RETURN, "Rail", "setOccupied_");
        }
    }
}
