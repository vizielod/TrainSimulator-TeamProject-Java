package movingelement;

import map.MapElement;
import sun.reflect.generics.reflectiveObjects.NotImplementedException;

/**
 * Created by turbosnakes on 2017. 03. 13..
 */
public abstract class MovingElement {
    public MapElement currentElement;
    public MapElement previousElement;

    public void nextStep() {
        throw new NotImplementedException();
    }

    public void atStation() {
        throw new NotImplementedException();
    }

    public void explode() {
        throw new NotImplementedException();
    }

    public void vanish() {
        throw new NotImplementedException();
    }

}
