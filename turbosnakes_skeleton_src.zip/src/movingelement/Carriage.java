package movingelement;

import map.Rail;
import skeleton.Logger_;

import java.awt.*;
import java.util.Scanner;

import static skeleton.Logger_.logEvent;
import static skeleton.Logger_.logEventType.RETURN;

/**
 * Created by turbosnakes on 2017. 03. 13..
 */
public class Carriage extends MovingElement {
    private Color _color;
    private Boolean _empty;

    public Color getColor() {
        if (logic.System_.currentUC == 9) {
            Logger_.logEvent(Logger_.logEventType.RETURN, "Carriage", "getColor");
        }
        return null;
    }

    public void empty() {
        if (logic.System_.currentUC == 9) {
            Logger_.logEvent(Logger_.logEventType.RETURN, "Carriage", "empty");
        }
    }

    public Boolean isEmpty() {
        if (logic.System_.currentUC == 9) {
            //A kocsik ürességének logikai vizsgálata jelenleg a tesztelő feladata.
            System.out.println("A kocsi üres? (0: Nem / 1: Igen)");
            Scanner sc = new Scanner(System.in);
            int input = sc.nextInt();
            if (input == 1) {
                Logger_.logEvent(Logger_.logEventType.RETURN, "Carriage", "isEmpty");
                //Ha a tesztelő igaz értéket írt be, azzal tér vissza a függvény.
                return true;
            } else if (input == 0) {
                logEvent(RETURN, "Carriage", "isEmpty");
                //Ha hamisat, akkor azzal.
                return false;
            } else throw new IllegalArgumentException();
        }
        return null;
    }

    private void inituc6() {
        currentElement = new Rail(); // csak a szkeleton miatt
    }

    @Override
    public void vanish() {
        if (logic.System_.currentUC == 6) {
            inituc6();
            Logger_.logEvent(Logger_.logEventType.CALL, "Carriage", "vanish", "Rail", "setOccupied", "null");
            currentElement.setOccupied_(null);
            Logger_.logEvent(Logger_.logEventType.RETURN, "Carriage", "vanish");
        }
    }

}
