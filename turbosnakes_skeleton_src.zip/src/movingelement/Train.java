package movingelement;

import logic.System_;
import map.Rail;
import map.Station;
import map.Switch_;
import map.TunnelEntrance;
import skeleton.Logger_;

import java.util.ArrayList;
import java.util.Scanner;

/**
 * Created by turbosnakes on 2017. 03. 13..
 */
public class Train extends MovingElement {
    private final ArrayList<Carriage> _carts = new ArrayList<>();

    /**
     * A vonat callback függvénye. Egy állomás akkor hívja meg, ha rá vonat érkezett.
     * Az utasok leszállítását végzi, illetve ha arra szükség van (a vonat kiürült), meghívja saját maga vanish() függvényét.
     */
    @Override
    public void atStation() {
        if (System_.currentUC == 9) {
            inituc9();

            //A tesztelőtől be kell kérni, hogy hány kocsi van a vonaton.
            System.out.println("\nHány kocsival szeretné elvégezni a tesztet? 1-től 5-ig adjon meg egy számot!");
            Scanner sc = new Scanner(System.in);
            int input = sc.nextInt();
            //A kocsik száma a teszt megkönnyítése érdekében 1 és 5 között lehet.
            if (input >= 0 && input <= 5) {
                for (int i = 0; i < input; i++)
                    _carts.add(new Carriage());
            } else throw new IllegalArgumentException();

            // A legelső, nem üres kocsi indexe.
            int firstFullCarriageIndex = 0;
            //Megmondja, hogy meg lett-e találva az első nem üres kocsi.
            Boolean firstFullFound = false;

            System.out.println("\nA legelső kocsitól haladva adja meg, hogy üres-e az egység! Muszáj legalább egy darab nem üres vagonnak lennie!");
            Logger_.logEvent(Logger_.logEventType.CALL, "Train", "atStation", "Carriage", "isEmpty", "");

            //Megkeresi a legelső, nem üres kocsit.
            while (!firstFullFound) {
                System.out.println(firstFullCarriageIndex + 1 + ". kocsi:");
                //Ha talál egy kocsit, ami nem üres, akkor vége a vizsgálatnak.
                if (!(_carts.get(firstFullCarriageIndex).isEmpty()))
                    firstFullFound = true;
                else
                    firstFullCarriageIndex++;
            }

            Logger_.logEvent(Logger_.logEventType.CALL, "Train", "atStation", "Carriage", "getColor", "");
            //A legelső, nem üres kocsinak le kell kérdezni a színét.
            _carts.get(firstFullCarriageIndex).getColor();
            Logger_.logEvent(Logger_.logEventType.CALL, "Train", "atStation", "Station", "getColor", "");
            //Lekérdezi az állomás színét, amin áll.
            ((Station) currentElement).getColor();

            //Mivel a Szkeletonban még nem feladat a színek kezelése, a tesztelőtől várjuk a választ arra, hogy megegyezik-e a kocsi és az állomás színe.
            System.out.println("\nMegegyezik ennek a kocsinak és az állomásnak a színe? (0: Nem / 1: Igen)");
            sc = new Scanner(System.in);
            input = sc.nextInt();
            // Ha megegyeznek a színek, akkor a kocsit ki kell üríteni.
            if (input == 1) {
                Logger_.logEvent(Logger_.logEventType.CALL, "Train", "atStation", "Carriage", "empty", "");
                _carts.get(firstFullCarriageIndex).empty();
            } else if (input != 0) throw new IllegalArgumentException();

            //Mivel előfordulhat, hogy változás történt a kocsik összetételében, végigmegyünk az összes kocsin újra, és megvizsgáljuk, hogy el kell-e tüntetni a szerelvényt.
            firstFullCarriageIndex = 0;
            //Megmondja, hogy átnéztük-e az összes nem üres kocsit a ciklusban.
            Boolean atTheEnd = false;
            //A vizsgálat a tesztelő bevonásával folyik, neki kell megmondania, hogy üresek-e az egyes kocsik.
            System.out.println("\nMegkezdődik a kocsik újbóli üresség-vizsgálata. A legelső kocsitól haladva adja meg, hogy üres-e az egység!");

            //Megnézi, hogy van-e üres kocsi.
            while (!atTheEnd) {
                if (firstFullCarriageIndex != _carts.size())
                    System.out.println(firstFullCarriageIndex + 1 + ". kocsi:");
                //Ha az aktuális kocsi nem üres, vagy nincs több vizsgálható kocsi, akkor megállunk.
                if (firstFullCarriageIndex == _carts.size() || !(_carts.get(firstFullCarriageIndex).isEmpty()))
                    atTheEnd = true;
                else
                    firstFullCarriageIndex++;
            }

            if (firstFullCarriageIndex == _carts.size()) {
                //Ha végigértünk a kocsikon, és mindegyik üres volt, akkor meghívjuk a vanish függvényt, ami eltünteti a vonatot, és visszatérünk.
                this.vanish();
                Logger_.logEvent(Logger_.logEventType.RETURN, "Train", "atStation");
            } else {
                //Ha végigértünk, és nincs teendő, akkor visszatérünk.
                Logger_.logEvent(Logger_.logEventType.RETURN, "Train", "atStation");
            }
        }
    }

    /**
     * Ha a vonat minden kocsija kiürült, akkor a vonat eltűnik. Ennek a szituációnak a lejezelésére szolgál ez a függvény.
     */
    @Override
    public void vanish() {
        if (System_.currentUC == 6) {
            inituc6();
            Logger_.logEvent(Logger_.logEventType.CALL, "Train", "vanish", "Carriage", "vanish", "");
            _carts.get(0).vanish();
            Logger_.logEvent(Logger_.logEventType.CALL, "Train", "vanish", "Station", "setOccupied_", "null");
            currentElement.setOccupied_(null);
            Logger_.logEvent(Logger_.logEventType.RETURN, "Train", "vanish");
        }
        if (System_.currentUC == 9) {
            //Mivel a vanish-nek külön use case lett elkészítve, itt cselekvés nélkül visszatér.
            Logger_.logEvent(Logger_.logEventType.RETURN, "Train", "vanish");
        }
    }

    /**
     * A rendszer léptetésének megfelelően a vonatnak is minden iterációban vannak feladatai (pl.: következő pályaelem lekérdezése). Ezen feladatok elvégzését végzi ez a függvény.
     */
    @Override
    public void nextStep() {
        if (System_.currentUC == 4) {
            inituc4();
            Logger_.logEvent(Logger_.logEventType.CALL, "Train", "nextStep", "Rail", "getNext", "previousElement");
            currentElement = currentElement.getNext_(previousElement);
            Logger_.logEvent(Logger_.logEventType.CALL, "Train", "nextStep", "Rail", "setOccupied_", "this");
            currentElement.setOccupied_(this);
            Logger_.logEvent(Logger_.logEventType.RETURN, "Train", "nextStep");
        }
        if (System_.currentUC == 9) {
            //A getOff use case inicializáló függvényének meghívása.
            inituc9();

            Logger_.logEvent(Logger_.logEventType.CALL, "Train", "nextStep", "Station", "getNext", "previousElement");
            //A jelenlegi pozíciótól le kell kérdezni a következőt. A visszakapott MapElement lesz az új currentElement.
            currentElement = ((Station) currentElement).getNext_(previousElement);

            Logger_.logEvent(Logger_.logEventType.CALL, "Train", "nextStep", "Station", "getNext", "previousElement");
            currentElement.setOccupied_(this);

            Logger_.logEvent(Logger_.logEventType.RETURN, "Train", "nextStep");
        }
        if (System_.currentUC == 1) {
            //A MEonRail use case inicializáló függvényének meghívása
            inituc1();
            Logger_.logEvent(Logger_.logEventType.CALL, "Train", "nextStep", "R1", "getNext", "previousElement" );
            //Lekérdezzük a jelenlegi elemtől, hogy mi lesz a következő elem. A visszakapott elem lesz az új jelenlegi elem
            currentElement = currentElement.getNext_(previousElement);
            Logger_.logEvent(Logger_.logEventType.CALL, "Train", "nextStep", "R2", "setOccupied_", "this");
            //Beállítjuk, hogy a vonat a getNext által visszaadott elemre kerüljön.
            currentElement.setOccupied_(this);
            //Visszatérünk a nextStep függvényből
            Logger_.logEvent(Logger_.logEventType.RETURN, "Train", "nextStep");
        }
        if (System_.currentUC == 11){
            //A MEonRail második lépését bemutató rész
            Logger_.logEvent(Logger_.logEventType.CALL, "Train", "nextStep", "R2", "getNext", "R1" );
            //Lekérjük a következő elemet, majd beállítjuk azt a jelenleginek.
            currentElement = currentElement.getNext_(previousElement);
            Logger_.logEvent(Logger_.logEventType.CALL, "Train", "nextStep", "R3", "setOccupied_", "this");
            //Az új jelenelegi elemre helyezzük a vonatot a setOccupied függvény segítségével.
            currentElement.setOccupied_(this);
            Logger_.logEvent(Logger_.logEventType.RETURN, "Train", "nextStep");
        }
        if (System_.currentUC == 2) {
            //A MEonSwitch use case inicializáló függvényének meghívása.
            inituc2();
            Logger_.logEvent(Logger_.logEventType.CALL, "Train", "nextStep", "R1", "getNext", "previousElement" );
            //Következő elem lekérése, majd beállítása az új jelenlegi elemnek.
            currentElement = currentElement.getNext_(previousElement);
            Logger_.logEvent(Logger_.logEventType.CALL, "Train", "nextStep", "Switch", "setOccupied_", "this");
            //Itt switchtre lép a vonat ezért a switch setOccupied függvénye hívódik, és beállítja, hogy a switchen melyik MovingElement van,
            //ebben az esetben ez a vonat.
            currentElement.setOccupied_(this);
            Logger_.logEvent(Logger_.logEventType.RETURN, "Train", "nextStep");
        }
        if (System_.currentUC == 20) {
            Logger_.logEvent(Logger_.logEventType.CALL, "Train", "nextStep", "Switch", "getNext", "R1");
            //A MEonSwitch második lépésének leírása, a switch utáni következő elemet kéri le.
            currentElement = currentElement.getNext_(previousElement);
        }
        if(System_.currentUC == 21) {
            Logger_.logEvent(Logger_.logEventType.CALL, "Train", "nextStep", "A", "setOccupied_", "this");
            //A felhasználói választás után, az "A" sínre lépést írja le.
            currentElement.setOccupied_(this);
            Logger_.logEvent(Logger_.logEventType.RETURN, "Train", "nextStep");
        }
        if(System_.currentUC == 22) {
            Logger_.logEvent(Logger_.logEventType.CALL, "Train", "nextStep", "B", "setOccupied_", "this");
            //A felhasználói választás után, a "B" sínre lépést írja le.
            currentElement.setOccupied_(this);
            Logger_.logEvent(Logger_.logEventType.RETURN, "Train", "nextStep");
        }
        if (System_.currentUC == 5) {
            //A MEinTunnel use case első felénnek inicializáló függvénye. A use caset azért kell külön venni 2 részletre,
            // mert 2 nextStep függvény hívás van.
            inituc5();
            Logger_.logEvent(Logger_.logEventType.CALL, "Train", "nextStep", "TunnelEntrance", "getNext", "previousElement");
            //A jelenlegi pozíciótól le kell kérdezni a következőt. A visszakapott MapElement lesz az új currentElement.
            currentElement = currentElement.getNext_(previousElement);
            Logger_.logEvent(Logger_.logEventType.CALL, "Train", "nextStep", "Rail", "setOccupied_", "this");
            //A currentElementet be kell állítani, hogy elfoglalt egy bizonyos MapElementet. A paraméter egy MovingElement, ami rááll a MapElementre.
            currentElement.setOccupied_(this);
            Logger_.logEvent(Logger_.logEventType.RETURN, "Train", "nextStep");
        }
        if (System_.currentUC == 51) {
            //A MEinTunnel use case második felénnek inicializáló függvénye.
            inituc51();
            Logger_.logEvent(Logger_.logEventType.CALL, "Train", "nextStep", "Rail", "getNext", "previousElement");
            //A jelenlegi pozíciótól le kell kérdezni a következőt. A visszakapott MapElement lesz az új currentElement.
            currentElement = currentElement.getNext_(previousElement);
            Logger_.logEvent(Logger_.logEventType.CALL, "Train", "nextStep", "TunnelEntrance", "setOccupied_", "this");
            //A currentElementet be kell állítani, hogy elfoglalt egy bizonyos MapElementet. A paraméter egy MovingElement, ami rááll a MapElementre.
            currentElement.setOccupied_(this);
            Logger_.logEvent(Logger_.logEventType.RETURN, "Train", "nextStep");
        }
        if (System_.currentUC == 8) {
            inituc8();
            Logger_.logEvent(Logger_.logEventType.CALL, "Train", "nextStep", "R1", "getNext", "previousElement");
            currentElement = currentElement.getNext_(previousElement);
            Logger_.logEvent(Logger_.logEventType.CALL, "Train", "nextStep", "Switch", "setOccupied_", "this");
            currentElement.setOccupied_(this);
            Logger_.logEvent(Logger_.logEventType.RETURN, "Train", "nextStep");
        }
        if (System_.currentUC == 81) {
            inituc81();
            Logger_.logEvent(Logger_.logEventType.CALL, "Train", "nextStep", "Switch", "getNext", "R1");
            currentElement = currentElement.getNext_(previousElement);
            System_ sys = new System_();
            Logger_.logEvent(Logger_.logEventType.CALL, "Train", "nextStep", "System", "gameOver", "");
            sys.gameOver();
        }
    }

    /**
     * Ha vonatok ütköznek, vagy rosszul áll egy váltó, akkor a vonat felrobban. Ennek megvalósítására szolgál ez a függvény.
     */
    @Override
    public void explode() {
        if (System_.currentUC == 4 || System_.currentUC == 9) {
            System_ sys = new System_();
            Logger_.logEvent(Logger_.logEventType.CALL, "Train", "explode", "System_", "gameOver", null);
            sys.gameOver();
            Logger_.logEvent(Logger_.logEventType.RETURN, "Train", "explode");
        }
    }

    private void inituc6() {
        if (System_.currentUC == 6) {
            _carts.add(new Carriage());
            currentElement = new Station();
        }
    }

    private void inituc9() {
        if (System_.currentUC == 9) {
            currentElement = new Station();
        }
    }

    private void inituc4() {
        if (System_.currentUC == 4) {
            currentElement = new Rail();
            previousElement = new Rail();
        }
    }

    public void inituc1() {
        //A MEonRail use case inicializáló függvénye, beállítja, hogy egy sínen áll és egy sínről érkezett a vonat.
        if (System_.currentUC == 1) {
            currentElement = new Rail();
            previousElement = new Rail();
        }
    }

    public void inituc5() {
        if (System_.currentUC == 5) {
            currentElement = new Rail();
            previousElement = new TunnelEntrance();
        }
    }

    public void inituc51() {
        if (System_.currentUC == 51) {
            currentElement = new TunnelEntrance();
            previousElement = new Rail();
        }
    }

    public void inituc2() {
        //A MEonSwitch use case inicializáló függvénye, beállítja, hogy egy sínen áll és egy sínről érkezett a vonat.
        if (System_.currentUC == 2) {
            currentElement = new Rail();
            previousElement = new Rail();
        }
    }

    public void inituc8() {
        if (System_.currentUC == 8) {
            currentElement = new Rail();
            previousElement = new Rail();
        }
    }

    public void inituc81() {
        if (System_.currentUC == 81) {
            currentElement = new Switch_();
            previousElement = new Rail();
        }
    }
}
