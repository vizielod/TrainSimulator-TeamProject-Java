package skeleton;

import logic.System_;

/**
 * Created by turbosnakes on 2017. 03. 15..
 * <p>
 * event_id lehetséges értékeinek jelentése:
 * 0 - hiba, piros
 * 1 - függvényhívás, fehér
 * 2 - visszatérés, fehér
 * 3 - uc sikeres, zöld
 * <p>
 * Használata:
 * LOGGER.logEvent(0, "MovingElement", "nextStep"); //Haszálat hiba esetén. Elég  csak megadni a jelenlegi osztályt és a függvényét.
 * LOGGER.logEvent(1, "MovingElement", "nextStep", "Station", "setOccupied", "&this"); //Használat függvényhívásnál.
 * LOGGER.logEvent(2, "MovingElement", "nextStep"); //Használat visszatérésnél. Ua. mint elsőnél, a kódból majd kideríti a többi részt.
 * LOGGER.logEvent(3, "MovingElement"); //Usecase befejezése esetén elég csak a jelenlegi elemet megadni.
 */
public class Logger_ {
    /**
     * ANSI escape színkódok. Nem minden konzolon működik, pl Windows-on NT-től kezdve 10-ig nem.
     * Segíthetik a színek a tesztelők munkáját, ha alkalmas konzolon futtatják.
     */
    private static final String ANSI_RESET = System_.ANSI_CONSOLE_ENABLED ? "\u001B[0m" : "";
    private static final String ANSI_BLACK = System_.ANSI_CONSOLE_ENABLED ? "\u001B[30m" : "";
    private static final String ANSI_RED = System_.ANSI_CONSOLE_ENABLED ? "\u001B[31m" : "";
    private static final String ANSI_GREEN = System_.ANSI_CONSOLE_ENABLED ? "\u001B[32m" : "";
    private static final String ANSI_YELLOW = System_.ANSI_CONSOLE_ENABLED ? "\u001B[33m" : "";
    private static final String ANSI_BLUE = System_.ANSI_CONSOLE_ENABLED ? "\u001B[34m" : "";
    private static final String ANSI_PURPLE = System_.ANSI_CONSOLE_ENABLED ? "\u001B[35m" : "";
    private static final String ANSI_CYAN = System_.ANSI_CONSOLE_ENABLED ? "\u001B[36m" : "";
    private static final String ANSI_WHITE = System_.ANSI_CONSOLE_ENABLED ? "\u001B[37m" : "";

    private static int count = 1; //A sorszámozást tároljuk benne.

    /**
     * Enum, a különböző, általunk naplózott események megkülönböztetésére
     * 0 - hiba, piros
     * 1 - függvényhívás, fehér
     * 2 - visszatérés, fehér
     * 3 - uc sikeres, zöld
     */
    public enum logEventType {
        ERROR,      //0 - hiba, piros
        CALL,       //1 - függvényhívás, fehér
        RETURN,     //2 - visszatérés, fehér
        UC_SUCCESS  //3 - uc sikeres, zöld
    }

    /**
     * Egy egyszerűsített alakja a logEvent függvénynek, ugyanis nincs mindig szükség a teljes szignatúra kiírására.
     * @param event_type Esemény típusa
     * @param a_type Az osztály, melyben bekövetkezett
     */
    public static void logEvent(logEventType event_type, String a_type) {
        writeConsole(event_type, a_type, "", "", "", "");
    }

    /**
     * Egy egyszerűsített alakja a logEvent függvénynek, ugyanis nincs mindig szükség a teljes szignatúra kiírására.
     *
     * @param event_type Esemény típusa
     * @param a_type     Az osztály, melyben bekövetkezett
     * @param a_function Az előbbi osztály mely függvényében történt
     */
    public static void logEvent(logEventType event_type, String a_type, String a_function) {
        writeConsole(event_type, a_type, a_function, "", "", "");
    }

    /**
     * A teljes szignatúrája a logEventnek.
     * @param event_type Esemény típusa
     * @param a_type Az osztály, melyben bekövetkezett
     * @param a_function Az előbbi osztály mely függvényében történt
     * @param b_type Az osztály, amivel csinált valamit
     * @param b_function Mely függvényét hívta meg az előbbi osztálynak
     * @param param Milyen paraméterrel
     */
    public static void logEvent(logEventType event_type, String a_type, String a_function, String b_type, String b_function, String param) {
        writeConsole(event_type, a_type, a_function, b_type, b_function, param);
    }

    /**
     * Kiírást végző függvény
     * @param event_type Esemény típusa
     * @param a_type Az osztály, melyben bekövetkezett
     * @param a_function Az előbbi osztály mely függvényében történt
     * @param b_type Az osztály, amivel csinált valamit
     * @param b_function Mely függvényét hívta meg az előbbi osztálynak
     * @param param Milyen paraméterrel
     */
    private static void writeConsole(logEventType event_type, String a_type, String a_function, String b_type, String b_function, String param) {
        String event; //Mi törént
        String verb = ""; //Az ige, vagyis a kiírás további része
        switch (event_type) {
            case ERROR:
                event = ANSI_RED + "hiba         " + ANSI_RESET;
                verb = "hibába ütközött";
                break;
            case CALL:
                event = ANSI_BLUE + "függvényhívás" + ANSI_RESET;
                verb = "meghívta";
                break;
            case RETURN:
                event = ANSI_CYAN + "visszatérés  " + ANSI_RESET;
                verb = "sikeresen visszatért";
                break;
            case UC_SUCCESS:
                event = ANSI_GREEN + "use case ok  " + ANSI_RESET;
                verb = "sikeresen befejezte a jelenleg futó use caset";
                break;
            default:
                event = "esemény";
                break;
        }
        System.out.printf("%02d", count); //Kiírjuk a sorszámot két digittel
        System.out.print(". " + event + " :" + " " + a_type); //Esemény típusa és az osztály melyben bekövetkezett

        //Mást írunk ki a különböző típusok esetén
        if (event_type != logEventType.UC_SUCCESS) System.out.print("." + a_function + "() függvénye " + verb);
        else System.out.print(" " + verb);
        if (event_type == logEventType.CALL)
            System.out.print(" " + b_type + "." + b_function + "() függvényét " + "\"" + param + "\"" + " paraméterrel");

        System.out.println("."); //Pont a mondat végére
        count++; //Növeljük a sorok számlálóját
    }
}
