package skeleton;

import logic.Player;
import logic.System_;
import map.Map;
import map.Tunnel;
import movingelement.Train;

/**
 * Ez az osztály fogja össze a különböző usecaseket és végzi el azok elindítását
 * Minden függvényében beállítjuk a megfelelő System_ változót a jelenleg futó UC számára.
 * Erre azért van szükség, mert elkerülhetőek különböző, eltérő inicializálásból fakadó hibák.
 *
 * Created by turbosnakes on 2017. 03. 15..
 */
public abstract class UseCases {
    /**
     * Use-case neve: 1 - MEonRail
     * Rövid leírás: MovingElement sínen mozog
     * Aktorok: MovingElement
     * Forgatókönyv: A Train vagy Carriage lépésenként lekérdezi az éppen aktuális síntől, hogy ki a következő.
     * Ezt a getNext függvény segítségével teszi, majd a setOccupied függvénnyel lefoglalja a következő sínt és rálép.
     * <p>
     * Készítette: Dobó
     */
    public static void uc1_MEonRail() {
        System_.currentUC = 1;
        Train t = new Train();
        Logger_.logEvent(Logger_.logEventType.CALL, "UseCases", "uc1_MEonRail", "Train", "nextStep", "");
        t.nextStep();
        System_.currentUC = 11;
        Logger_.logEvent(Logger_.logEventType.CALL, "UseCases", "uc1_MEonRail", "Train", "nextStep", "");
        t.nextStep();
        Logger_.logEvent(Logger_.logEventType.UC_SUCCESS, "MEonRail");
        System_.currentUC = 0;
    }

    /**
     * Use-case neve: 2 - MEonSwitch
     * Rövid leírás: Mozgás miközben váltóra ér a Train vagy Carriage
     * Aktorok: MovingElement
     * Forgatókönyv: A Train vagy Carriage egy sínről egy Switchre lép, ahol lekérdezni a következő elemet és a
     * switch állásától függően a megfelelő irányban halad tovább.
     * Készítette: Dobó
     */
    public static void uc2_MEonSwitch() {
        System_.currentUC = 2;
        Train t = new Train();
        Logger_.logEvent(Logger_.logEventType.CALL, "UseCases", "uc2_MEonSwitch", "Train", "nextStep", "");
        t.nextStep();
        System_.currentUC = 20;
        Logger_.logEvent(Logger_.logEventType.CALL, "UseCases", "uc2_MEonSwitch", "Train", "nextStep", "");
        t.nextStep();
        Logger_.logEvent(Logger_.logEventType.UC_SUCCESS, "MEonSwitch");
        System_.currentUC = 0;
    }

    /**
     * Use-case neve: 3 - ManageTunnel
     * Rövid leírás: Alagút építése és megszüntetése
     * Aktorok: User
     * Forgatókönyv: Mikor egy új Tunnelt próbál meg a felhasználó engedélyezni, először végignézzük a
     * TunnelEntranceokat és az alagúton belüli Rail elemeket, hogy üresek-e. Ha mindegyik üres
     * (nem volt rajta Train vagy Carriage) a régi Tunnel bezáródik és az új Tunnel létrejön az enable() függvény
     * segítségével.
     * Készítette: Fenes
     */
    public static void uc3_ManageTunnel() {
        System_.currentUC = 3;
        Map map = new Map();
        Tunnel newTunnel = new Tunnel();
        Logger_.logEvent(Logger_.logEventType.CALL, "UseCases", "uc3_ManageTunnel", "Map", "enableTunnel", "newTunnel");
        //A felhasználó a függvénynek átadott Tunnel paraméterrel kezdeményezi az új alagút építését
        map.enableTunnel(newTunnel);
        Logger_.logEvent(Logger_.logEventType.UC_SUCCESS, "ManageTunnel");
        System_.currentUC = 0;
    }

    /**
     * Use-case neve: 4 - Collision
     * Rövid leírás: Ütközés
     * Aktorok: MovingElement
     * Forgatókönyv: Egy train olyan Rail-re próbál lépni, ahol már van valami. Mikor megpróbálja elfoglalni (setOccupied) akkor a Rail meghívja az explode függvényét, amit egy gameOver követ. A másik vonatot felrobbantásával nem kell foglazni, hiszen ezen a ponton már úgy is vége van a játéknak.
     * Készítette: Papp
     */
    public static void uc4_Collision() {
        logic.System_.currentUC = 4;
        Train train = new Train();
        Logger_.logEvent(Logger_.logEventType.CALL, "UseCases", "uc4_Collision", "Train", "nextStep", "");
        train.nextStep();
        Logger_.logEvent(Logger_.logEventType.UC_SUCCESS, "Collision");
        System_.currentUC = 0;
    }

    /**
     * Use-case neve: 5 - MEinTunnel
     * Rövid leírás: Alagútban haladás
     * Aktorok: MovingElement
     * Forgatókönyv: A Train vagy Carriage először lekérdezi az éppen aktuális síntől, hogy ki a következő TunnelEntrance.
     * Ezt a getNext függvény segítségével teszi, majd a setOccupied függvénnyel lefoglalja és rálép. Az alagúton belül ugyanezen az elven történik a lépés, csak ott Rail-t kérdez le és foglal el.
     * Készítette: Fenes
     */
    public static void uc5_MEinTunnel() {
        System_.currentUC = 5;
        Train t = new Train();
        Logger_.logEvent(Logger_.logEventType.CALL, "UseCases", "uc5_MEinTunnel", "Train", "nextStep", "");
        //vonat léptetése
        t.nextStep();
        System_.currentUC = 51;
        Logger_.logEvent(Logger_.logEventType.CALL, "UseCases", "uc1_MEonRail", "Train", "nextStep", "");
        //vonat léptetése
        t.nextStep();
        Logger_.logEvent(Logger_.logEventType.UC_SUCCESS, "MEinTunnel");
        System_.currentUC = 0;
    }

    /**
     * Use-case neve: 6 - MEvanish
     * Rövid leírás: MovingElement eltűntetése, ha már egy vonat összes kocsija kiürült.
     * Aktorok: MovingElement
     * Forgatókönyv: Meghívódik a vonat vanish függvénye, ami meghívja az összes hozzá tartozó kocsinak ugyan ezen nevű
     * függvényét, amelyek beállítják azon elem foglaltságát, amin tartózkodnak. Ezt követően a vonat is megteszi ezt majd megszűnteti magát.
     * Készítette: Papp
     */
    public static void uc6_MEvanish() {
        logic.System_.currentUC = 6;
        Train train = new Train();
        Logger_.logEvent(Logger_.logEventType.CALL, "UseCases", "uc6_MEvanish", "Train", "vanish", "");
        train.vanish();
        Logger_.logEvent(Logger_.logEventType.UC_SUCCESS, "MEvanish");
        System_.currentUC = 0;
    }

    /**
     * Use-case neve: 7 - initMap
     * Rövid leírás: Pálya inicializálása
     * Aktorok: User
     * Forgatókönyv: A játék elindításakor a Map betölti a fájlból a pályát, majd létrehozza a fájlban található
     * elemeket. Ebben az esetben 1 darabot mindegyik MapElement-ből
     * Készítette: Vizi
     */
    public static void uc7_initMap() {
        System_.currentUC = 7;
        System_ sys = new System_();
        Logger_.logEvent(Logger_.logEventType.CALL, "UseCases", "uc7_initMap", "System_", "start", "");
        sys.start();
        System_.currentUC = 0;
    }

    /**
     * Use-case neve: 8 - badSwitch
     * Rövid leírás: Olyan Switch állás, amin a vonat nem tud továbbhaladni.
     * Aktorok: MovingElement
     * Forgatókönyv: Ha a vonat Switchre lép és a tőle lekérdezett következő elem null értékű (ez egy olyan rossz Switch állás, amikor a vonat nem haladhat tovább), akkor a játéknak vége.
     * Készítette: Vizi
     */
    public static void uc8_badSwitch() {
        System_.currentUC = 8;
        Train train = new Train();
        Logger_.logEvent(Logger_.logEventType.CALL, "UseCases", "uc8_badSwitch", "Train", "nextStep", "");
        train.nextStep();
        System_.currentUC = 81;
        Logger_.logEvent(Logger_.logEventType.CALL, "UseCases", "uc8_badSwitch", "Train", "nextStep", "");
        train.nextStep();
        Logger_.logEvent(Logger_.logEventType.UC_SUCCESS, "badSwitch");
        System_.currentUC = 0;
    }

    /**
     * Use-case neve: 9 - getOff
     * Rövid leírás: Utasok leszállítása
     * Aktorok: MovingElement
     * Forgatókönyv: Ha a szerelvény egy állomáshoz ér, akkor a Train megkeresi a legelső nem üres kocsit, és annak
     * színét összeveti az állomás színével. Ha a két szín egyezik, az utasok leszállnak a kocsiról.
     * Ha ezáltal minden kocsi kiürült, akkor a vonat eltűnik.
     * Továbblépéskor ellenőrzésre kerül az is, hogy nincs-e ütközés (azaz hogy a következő pályaelemen tartózkodik-e
     * már valaki, amikor rálép a vonat).
     * Készítette: Salamon
     */
    public static void uc9_getOff() {
        System_.currentUC = 9;
        Train train = new Train();
        Logger_.logEvent(Logger_.logEventType.CALL, "UseCases", "uc9_getOff", "Train", "nextStep", "");
        train.nextStep();
        System_.currentUC = 0;
        Logger_.logEvent(Logger_.logEventType.UC_SUCCESS, "getOff");
    }

    /**
     * Use-case neve: 10 - setSwitch
     * Rövid leírás: A váltó állítása.
     * Aktorok: User
     * Forgatókönyv: A játékos, ha a megfelelő parancsot adja ki (readCommand), akkor a váltót át tudja állítani
     * egyik állásból a másikba (switch).
     * Készítette: Salamon
     */
    public static void uc10_setSwitch() {
        System_.currentUC = 10;
        Player player = new Player();
        Logger_.logEvent(Logger_.logEventType.CALL, "UseCases", "uc10_setSwitch", "Player", "readCommand", "");
        player.readCommand();
        Logger_.logEvent(Logger_.logEventType.UC_SUCCESS, "setSwitch");
        System_.currentUC = 0;
    }
}
