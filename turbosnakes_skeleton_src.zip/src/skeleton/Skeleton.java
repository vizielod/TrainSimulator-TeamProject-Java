package skeleton;

import logic.System_;

import java.util.Scanner;

/**
 * Ezt az osztályt (illetve Packaget) abból a célból vezettük be, hogy összefogja a szkeletonnal kapcsolatos
 * teendőket, hogy később jól elhatárolhatóak legyenek azok a tényleges programtől.
 * Created by turbosnakes on 2017. 03. 16..
 */
public abstract class Skeleton {
    /**
     * Elindítja a Skeleton törzsét.
     */
    public static void initSkeleton() {
        //Csinos kis fejlécet kirajzolunk
        System.out.println("---------------------------------------------------------------------------");
        System.out.println("| Üdvözli Önt a turbosnakes csapat projlab tárgyra készített szkeletonja. |");
        System.out.println("---------------------------------------------------------------------------");
        /**
         * Meg kell kérdezni a felhasználótól, hogy alkalmas-e a konzolja erre. Ha mi magunk derítenénk ki
         * szükség lenne platformfüggő könyvtárak importálására.
         */
        System.out.print("Támogatja az ANSI escape karaktereket a konzolja? \n(Alapesetben Linux igen, Windows csak 10-től, egy külön beállítással) \n0: Nem / 1 : Igen ");
        Scanner sc = new Scanner(System.in);
        int number;
        int exit;
        //Beolvasás
        try {
            while (!sc.hasNextInt()) {
                System.out.print("Ez nem egy szám! Írja be újra!");
                sc.next();
            }
            number = sc.nextInt();
            System_.ANSI_CONSOLE_ENABLED = number == 1 ? true : false;
        } catch (Exception e) {
            e.printStackTrace();
        }

        /**
         * A főmenő kezelése. Kiírjuk a menüpontokat és a menüpont számának beírásával indulhat el a teszteset.
         * Érvénytelen bemenet esetén ismét kérjük, hogy írja be.
         */
        do {
            System.out.println("\nKérem válasszon az alábbi menüpontok közül a szám beírásával:");
            System.out.println(
                    "\t[0] Exit \n" +
                            "\t[1] MEonRail \n" +
                            "\t[2] MEonSwitch \n" +
                            "\t[3] ManageTunnel\n" +
                            "\t[4] Collision\n" +
                            "\t[5] MEinTunnel\n" +
                            "\t[6] MEvanish\n" +
                            "\t[7] initMap\n" +
                            "\t[8] badSwitch\n" +
                            "\t[9] getOff\n" +
                            "\t[10] setSwitch\n"
            );

            System.out.print("\nÍrja be a válaszott menüpontot:");
            while (!sc.hasNextInt()) {
                System.out.println("Ez nem egy menüpont száma!");
                sc.next();
            }
            try {
                number = sc.nextInt();
                /**
                 * Itt kötjük össze a bemenetet a tényleges UC-val.
                 */
                switch (number) {
                    case 0:
                        System.out.println("\n\tViszontlátásra!\n");
                        System.exit(0);
                        break;
                    case 1:
                        System.out.println("\nMEonRail futtatása..");
                        UseCases.uc1_MEonRail();
                        break;
                    case 2:
                        System.out.println("\nMEonSwitch futtatása..");
                        UseCases.uc2_MEonSwitch();
                        break;
                    case 3:
                        System.out.println("\nManageTunnel futtatása..");
                        UseCases.uc3_ManageTunnel();
                        break;
                    case 4:
                        System.out.println("\nCollision futtatása..");
                        UseCases.uc4_Collision();
                        break;
                    case 5:
                        System.out.println("\nMEinTunnel futtatása..");
                        UseCases.uc5_MEinTunnel();
                        break;
                    case 6:
                        System.out.println("\nMEvanish futtatása..");
                        UseCases.uc6_MEvanish();
                        break;
                    case 7:
                        System.out.println("\ninitMap futtatása..");
                        UseCases.uc7_initMap();
                        break;
                    case 8:
                        System.out.println("\nbadSwitch futtatása..");
                        UseCases.uc8_badSwitch();
                        break;
                    case 9:
                        System.out.println("\ngetOff futtatása..");
                        UseCases.uc9_getOff();
                        break;
                    case 10:
                        System.out.println("\nsetSwitch futtatása..");
                        UseCases.uc10_setSwitch();
                        break;
                }
            } catch (Exception e) {
                /**
                 * Kezeljük a futásidőbeli és egyéb hibákat egy csinos hibaüzenettel!
                 */
                Logger_.logEvent(Logger_.logEventType.ERROR, "Skeleton", "initSkeleton");
                System.out.println("\nVáratlan, futásidőbeli hiba keletkezett. Valószínűleg egy helytelen felhasználói bemenet " +
                        "általi túlindexelés. " +
                        "\nHa biztos benne, hogy a hibát nem Ön idézte elő, " +
                        "kérem vegye fel a turbosnakes csapat valamelyik tagjával a kapcsolatot és kérjen segítséget! \n" +
                        "Említse meg neki melyik UC-ben és milyen bemenet hatására történt a jelenség." +
                        "\n\tKöszönjük!");
            }

            System.out.print("\nSzeretne másik use case-t futtatni? (0: Nem / 1: Igen)");
            Scanner scan = new Scanner(System.in);
            try {
                exit = scan.nextInt();
            } catch (Exception e) {
                exit = 0;
            }

            /**
             * Ha ANSI escape karakterekkel működik a konzol, akkor töröljük.
             * Ha nem, akkor írjunk is 50 db új sort.
             */
            if (exit != 0 & System_.ANSI_CONSOLE_ENABLED == true) {
                System.out.print("\033[H\033[2J");
                System.out.flush();
            } else {
                for (int i = 0; i < 50; i++) System.out.println("");
            }
        } while (exit != 0);
        System.out.println("\n\tViszontlátásra!\n");
    }
}
